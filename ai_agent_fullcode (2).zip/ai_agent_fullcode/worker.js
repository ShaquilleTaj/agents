import OpenAI from "openai";

export default {
  async fetch(request, env) {
    const client = new OpenAI({ apiKey: env.OPENAI_API_KEY });

    async function llm(prompt, maxTokens = 600) {
      const completion = await client.chat.completions.create({
        model: "gpt-4o-mini",
        messages: [{ role: "user", content: prompt }],
        max_tokens: maxTokens
      });
      return completion.choices[0].message.content;
    }

    async function fetchRSS(url) {
      const res = await fetch(url);
      const text = await res.text();
      const titles = [...text.matchAll(/<title>(.*?)<\/title>/g)]
        .slice(1, 11)
        .map(m => m[1]);
      return titles;
    }

    async function fetchTopics() {
      const feeds = [
        "https://hnrss.org/frontpage",
        "https://dev.to/feed/tag/ai",
        "https://www.reddit.com/r/MachineLearning/.rss",
        "https://www.reddit.com/r/LocalLLaMA/.rss"
      ];
      let topics = [];
      for (let url of feeds) {
        try {
          const titles = await fetchRSS(url);
          topics.push(...titles);
        } catch (_) {}
      }
      return topics;
    }

    async function scoreTopics(topics) {
      let results = [];
      for (let t of topics.slice(0, 10)) {
        const prompt = `
Score this topic for developer search intent and relevance to AI tools.
Return JSON with fields topic and intent_score.
Topic: ${t}
        `;
        const score = await llm(prompt, 200);
        results.push({ topic: t, score });
      }
      return results;
    }

    async function generateTutorial(topic) {
      const prompt = `
Write a structured developer tutorial for:
${topic}
Include explanation, steps, code examples, and a real use case.
      `;
      return llm(prompt, 1000);
    }

    async function generateThread(topic) {
      const prompt = `
Create a concise X style thread about:
${topic}
Include a hook, insights, a mini code sample, and a CTA.
      `;
      return llm(prompt, 300);
    }

    async function optimizeSEO(content, topic) {
      const prompt = `
Generate SEO metadata for an article on ${topic}
Output JSON with title, description, keywords.
Content sample: ${content.slice(0, 800)}
      `;
      const meta = await llm(prompt, 250);
      return { content, seo: meta };
    }

    function mockAnalytics() {
      return {
        pageviews: Math.floor(Math.random() * 200) + 100,
        engagement: 0.55,
        ctr: 4.3
      };
    }

    async function analyzeAnalytics(data) {
      const prompt = `
Given this analytics data: ${JSON.stringify(data)}
Provide three specific improvements for next week.
      `;
      return llm(prompt, 200);
    }

    async function runAgent() {
      const topics = await fetchTopics();
      const scored = await scoreTopics(topics);
      const chosen = scored[0].topic;

      const tutorial = await generateTutorial(chosen);
      const thread = await generateThread(chosen);
      const optimized = await optimizeSEO(tutorial, chosen);
      const analytics = mockAnalytics();
      const recommendations = await analyzeAnalytics(analytics);

      return {
        topic: chosen,
        tutorial: optimized,
        thread,
        analytics,
        recommendations
      };
    }

    const url = new URL(request.url);

    if (url.pathname === "/run") {
      const output = await runAgent();
      return new Response(JSON.stringify(output, null, 2), {
        headers: { "Content-Type": "application/json" }
      });
    }

    if (url.pathname === "/breakdown") {
      const output = await runAgent();
      const summary = await llm(
        `Break down this agent output and provide insights: ${JSON.stringify(output)}`,
        600
      );
      return new Response(JSON.stringify({ breakdown: summary }, null, 2), {
        headers: { "Content-Type": "application/json" }
      });
    }

    return new Response("AI Agent Worker Online. Use /run or /breakdown.");
  }
};
