import { useState } from "react";
import "./App.css";

const WORKER_URL = "https://YOUR-WORKER-URL";

export default function App() {
  const [data, setData] = useState(null);
  const [breakdown, setBreakdown] = useState(null);
  const [loading, setLoading] = useState(false);

  async function runAgent() {
    setLoading(true);
    setBreakdown(null);

    const res = await fetch(`${WORKER_URL}/run`);
    const json = await res.json();
    setData(json);
    setLoading(false);
  }

  async function runBreakdown() {
    const res = await fetch(`${WORKER_URL}/breakdown`);
    const json = await res.json();
    setBreakdown(json.breakdown);
  }

  function renderBlurb() {
    if (!data) return "";
    const topic = data.topic;
    return `
This article discusses ${topic} and provides a detailed technical walkthrough,
key insights, and a hands-on developer pathway. It highlights why this topic
matters, how to get started, and what real-world problems it solves.
    `;
  }

  return (
    <div className="container">
      <h1>AI Content Generator Dashboard</h1>

      <button disabled={loading} onClick={runAgent}>
        {loading ? "Running Agent..." : "Run Agent"}
      </button>

      {data && (
        <>
          <section className="card">
            <h2>Topic Selected</h2>
            <p>{data.topic}</p>
          </section>

          <section className="card">
            <h2>Blurb</h2>
            <p>{renderBlurb()}</p>
          </section>

          <section className="card">
            <h2>Tutorial Content</h2>
            <pre>{data.tutorial.content}</pre>
          </section>

          <section className="card">
            <h2>SEO Metadata</h2>
            <pre>{JSON.stringify(data.tutorial.seo, null, 2)}</pre>
          </section>

          <section className="card">
            <h2>Social Thread</h2>
            <pre>{data.thread}</pre>
          </section>

          <section className="card">
            <h2>Analytics</h2>
            <pre>{JSON.stringify(data.analytics, null, 2)}</pre>
          </section>

          <button onClick={runBreakdown}>
            Generate GPT Breakdown
          </button>

          {breakdown && (
            <section className="card">
              <h2>GPT Breakdown</h2>
              <pre>{breakdown}</pre>
            </section>
          )}
        </>
      )}
    </div>
  );
}
