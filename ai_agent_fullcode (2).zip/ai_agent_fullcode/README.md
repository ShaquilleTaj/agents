AI Content Agent + Dashboard

A complete serverless AI system combining a Cloudflare Worker backend, an automated AI content-generation agent, and a React dashboard. The agent discovers trending developer topics, scores them, generates full technical tutorials, creates social threads, produces SEO metadata, simulates analytics, and generates AI-driven breakdowns. The dashboard provides a clean UI to trigger runs, review outputs, and analyze results.

This project is designed to be extremely easy to run, deploy, and showcase as part of a professional portfolio or job application.

⭐ Features
AI Agent (Cloudflare Worker)

Fetches trending topics from multiple RSS feeds

Scores topics using GPT

Generates a full technical tutorial

Generates a social thread (X/Twitter style)

Produces SEO metadata (title, description, keywords)

Simulates analytics

Generates a detailed GPT-driven breakdown via /breakdown

Fully serverless and auto-scaling

React Dashboard

Trigger AI agent execution

Display topic, tutorial, SEO metadata, thread, analytics, and breakdown

Auto-generate article blurbs

Clean UI built with React + Vite

Optional Enhancements

Automatic runs via Cloudflare Cron

Persistent memory using Supabase

Pubic shareable content pages

Historical insights

📁 Project Structure
ai_agent/
 ├── worker.js                # Serverless AI Agent backend
 ├── README.md                # This file
 ├── package.json
 ├── index.html
 └── src/
      ├── App.jsx             # Dashboard UI
      ├── App.css             # Styling
      └── main.jsx            # React entry point

🔧 Backend Setup (Cloudflare Worker)
1. Install Wrangler CLI
npm install -g wrangler

2. Add your OpenAI API key

Create or update wrangler.toml:

name = "ai-agent-worker"
main = "worker.js"
compatibility_date = "2024-01-01"

[vars]
OPENAI_API_KEY = "sk-yourkeyhere"


Or use secrets:

wrangler secret put OPENAI_API_KEY

3. Deploy the Worker
wrangler deploy


After deployment, you will receive a URL like:

https://ai-agent-worker.username.workers.dev

🌐 Configure the Dashboard

Inside src/App.jsx, update:

const WORKER_URL = "https://ai-agent-worker.username.workers.dev";

🖥️ Frontend Setup (React + Vite)
1. Install dependencies
npm install

2. Run the dashboard
npm run dev


Dashboard URL:

http://localhost:5173

🚀 How to Use the Dashboard
Run Agent

Click Run Agent to execute:

Topic selection

Tutorial generation

Social thread generation

SEO metadata creation

Analytics simulation

Generate Breakdown

Click Generate GPT Breakdown for:

Topic interpretation

Tutorial quality assessment

SEO strength score

Social thread evaluation

Recommendations for next cycle

🔥 API Endpoints
GET /run

Runs the entire pipeline:

curl https://YOUR-WORKER-URL/run

GET /breakdown

Runs the agent and returns a GPT breakdown:

curl https://YOUR-WORKER-URL/breakdown

🔑 API Key Setup

The system requires:

OPENAI_API_KEY

If you didn't set it in wrangler.toml, use:

wrangler secret put OPENAI_API_KEY


Cloudflare encrypts this automatically.

⏱️ Automated Schedules (Optional)

Add to your wrangler.toml:

[triggers]
crons = ["0 */12 * * *"]   # runs every 12 hours


Modify worker.js to store outputs (e.g., to Supabase).

🗄️ Supabase Memory (Optional)
1. Install Supabase client
npm install @supabase/supabase-js

2. Add environment variables
wrangler secret put SUPABASE_URL
wrangler secret put SUPABASE_SERVICE_KEY

3. Store run data

Inside runAgent():

await supabase.from("runs").insert({
  topic: chosen,
  tutorial: optimized.content,
  seo: optimized.seo,
  analytics,
  recommendations,
  created_at: new Date().toISOString()
});


This enables:

Run history

Analytics over time

Agent performance tuning

🧠 Architecture Diagram
          ┌──────────────────────────────────────┐
          │          Cloudflare Worker            │
          │     /run          /breakdown          │
          └──────┬───────────────────┬────────────┘
                 │                   │
          Fetch RSS            GPT Breakdown
                 │                   │
                 ▼                   ▼
        Topic Scoring (GPT)   Structured Analysis
                 │
                 ▼
       Tutorial + Thread + SEO (GPT)
                 │
                 ▼
         Analytics Simulation
                 │
                 ▼
         JSON Returned to UI
                 │
                 ▼
     React Dashboard (interactive viewer)

❗ Troubleshooting
Dashboard is blank

You forgot to set:

const WORKER_URL = "https://your-worker.workers.dev";

CORS error

Add to Worker responses:

"Access-Control-Allow-Origin": "*"

Unauthorized Error

Run again:

wrangler secret put OPENAI_API_KEY

🛠️ Future Improvements

Add dark mode

Add a run history UI

Add charts for analytics over time

Add user accounts with Supabase Auth

Add ability to pick models manually

Add multi-model support (Claude, Gemini, Local models)

Add article publishing integrations (Dev.to, Medium)